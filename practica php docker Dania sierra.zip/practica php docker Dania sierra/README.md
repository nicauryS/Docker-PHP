Hola, para ejecutar esta aplicacion debes tener docker instalado en tu PC. Luego que clones el repositorio,
un archivo llamado .env en el cual vas a indicar la clave de mysql.

Para ejecutar la aplicacion, ejecutar el comando:
docker compose up -d

Si es la primera vez, ejecutas el comando:
docker compose up --build

Para detener la aplicacion, ejecutas el comando:
docker compose down
